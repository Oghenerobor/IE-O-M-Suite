import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Wrench, ClipboardCheck, Zap, FileText, BookOpen, LogOut } from 'lucide-react';

const LOGO_URL = "https://www.kindpng.com/picc/m/629-6292350_ikeja-electricity-hd-png-download.png";
const SHARED_PASSWORD = "IkejaO&M25";

function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password === SHARED_PASSWORD) {
      setError('');
      onLogin(email);
    } else {
      setError('Incorrect password. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-600 to-yellow-400 flex items-center justify-center p-4">
      <motion.div
        className="w-full max-w-md bg-white rounded-2xl shadow-lg p-6 text-gray-800"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex flex-col items-center mb-4">
          <img src={LOGO_URL} alt="Ikeja Electric Logo" className="w-20 h-20 rounded-full shadow-md mb-3 bg-white p-1" />
          <h1 className="text-2xl font-bold">IE O&M Suite</h1>
          <p className="text-sm italic text-gray-600 mt-1">Bringing Energy to Life</p>
        </div>

        <p className="text-gray-700 mb-4">Welcome to the IE O&M Suite — your one-stop portal for field operations and documentation.</p>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="text-sm font-medium">Email</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full mt-1 p-2 border rounded-lg"
              placeholder="you@ikejaelectric.com"
            />
          </div>
          <div>
            <label className="text-sm font-medium">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full mt-1 p-2 border rounded-lg"
              placeholder="Enter shared password"
            />
          </div>
          {error && <div className="text-red-600 text-sm">{error}</div>}
          <button type="submit" className="w-full bg-red-600 text-white font-semibold py-2 rounded-lg mt-2">Login</button>
        </form>
      </motion.div>
    </div>
  );
}

function Dashboard({ onLogout, userEmail }) {
  const forms = [
    { title: 'Near Miss Documentation', link: 'https://forms.gle/63FMV6ocWHSMuenJA', Icon: AlertTriangle, desc: 'Record and document any near miss incidents.' },
    { title: 'Daily Fault Log', link: 'https://forms.gle/asRvNuygah39H5Ej6', Icon: Wrench, desc: 'Log daily faults and corrective actions.' },
    { title: 'MD Customers Recertification', link: 'https://forms.gle/ap9x8VqkvbvMapJ47', Icon: ClipboardCheck, desc: 'Submit recertification for MD customers.' },
    { title: 'Public DT Recertification', link: 'https://forms.gle/Rarv6GeFQYo22BcG9', Icon: Zap, desc: 'Report recertification of public DTs.' }
  ];

  const extra = [
    { title: 'Reports', Icon: FileText, desc: 'Compiled reports and submissions.', link: '#' },
    { title: 'Resources', Icon: BookOpen, desc: 'Operational guidelines and training.', link: '#' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-600 to-yellow-400 p-6 text-white">
      <header className="flex items-center justify-between max-w-6xl mx-auto mb-6">
        <div className="flex items-center gap-4">
          <img src={LOGO_URL} alt="Ikeja Electric" className="w-14 h-14 rounded-full bg-white p-1 shadow-md" />
          <div>
            <h1 className="text-2xl font-bold">IE O&M Suite</h1>
            <p className="text-sm italic">Bringing Energy to Life</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-sm">Signed in as <strong>{userEmail || 'staff'}</strong></div>
          <button
            onClick={onLogout}
            className="bg-white text-red-600 px-3 py-2 rounded-lg font-semibold flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto">
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {forms.map((f, i) => (
            <div key={i} className="bg-white text-gray-800 rounded-2xl p-5 shadow-md">
              <div className="flex items-center gap-3 mb-3">
                <f.Icon className="w-8 h-8 text-red-600" />
                <h2 className="text-lg font-semibold">{f.title}</h2>
              </div>
              <p className="text-sm text-gray-600 mb-4">{f.desc}</p>
              <button onClick={() => window.open(f.link, '_blank')} className="bg-red-600 text-white px-4 py-2 rounded-full font-semibold">Open Form</button>
            </div>
          ))}
        </section>

        <h3 className="text-xl font-bold mt-10 mb-4">Additional Sections</h3>
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {extra.map((s, i) => (
            <div key={i} className="bg-white text-gray-800 rounded-2xl p-5 shadow-md">
              <div className="flex items-center gap-3 mb-3">
                <s.Icon className="w-8 h-8 text-yellow-500" />
                <h4 className="text-lg font-semibold">{s.title}</h4>
              </div>
              <p className="text-sm text-gray-600 mb-4">{s.desc}</p>
              <button onClick={() => window.open(s.link, '_blank')} className="bg-yellow-500 text-white px-4 py-2 rounded-full font-semibold">Open</button>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}

function LoggedOutScreen({ onReturn }) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-red-600 to-yellow-400 flex items-center justify-center p-4">
      <div className="max-w-md bg-white rounded-2xl shadow-lg p-6 text-gray-800 text-center">
        <h2 className="text-2xl font-bold mb-3">You’ve been logged out successfully</h2>
        <p className="mb-4">Please close this tab or log in again to continue.</p>
        <button onClick={onReturn} className="bg-red-600 text-white px-4 py-2 rounded-lg font-semibold">Return to Login</button>
      </div>
    </div>
  );
}

export default function App() {
  // Session-only auth: stored in-memory so refresh resets (user must login again)
  const [auth, setAuth] = useState({ isAuthenticated: false, email: null, loggedOut: false });

  const handleLogin = (email) => {
    setAuth({ isAuthenticated: true, email, loggedOut: false });
  };

  const handleLogout = () => {
    // clear in-memory auth and show logged out screen
    setAuth({ isAuthenticated: false, email: null, loggedOut: true });
  };

  const returnToLogin = () => {
    setAuth({ isAuthenticated: false, email: null, loggedOut: false });
  };

  if (auth.loggedOut) {
    return <LoggedOutScreen onReturn={returnToLogin} />;
  }

  if (!auth.isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return <Dashboard onLogout={handleLogout} userEmail={auth.email} />;
}